﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class TargetPlatform : MonoBehaviour
{
    public static BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;

    [MenuItem("BundleBuilder/Switch Platform/Standlone Windows")]
    public static void SwitchWindowsPlatform()
    {
        buildTarget = BuildTarget.StandaloneWindows;
        EditorUserBuildSettings.SwitchActiveBuildTarget(buildTarget);
    }

    [MenuItem("BundleBuilder/Switch Platform/IOS")]
    public static void SwitchIOSPlatform()
    {
        buildTarget = BuildTarget.iPhone;
        EditorUserBuildSettings.SwitchActiveBuildTarget(buildTarget);
    }

    [MenuItem("BundleBuilder/Switch Platform/Android")]
    public static void SwitchAndroidPlatform()
    {
        buildTarget = BuildTarget.Android;
        EditorUserBuildSettings.SwitchActiveBuildTarget(buildTarget);
    }
}

[InitializeOnLoad]
public class PlatformInfo
{
    static PlatformInfo()
    {
        EditorUserBuildSettings.activeBuildTargetChanged += OnChangePlatform;
    }
    static void OnChangePlatform()
    {
        Debug.Log("Has Pro Licence : " + Application.HasProLicense());
        Debug.Log("Platform : " + EditorUserBuildSettings.activeBuildTarget);
    }
}
