﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class BuildEffect : MonoBehaviour
{
    static string targetPath = Application.dataPath + "/StreamingAssets/Effect/";
    static string mainProjectPath = targetPath;

    [MenuItem(@"BundleBuilder/Effect/Create All Effect Assets.")]
    public static void CreateAllEffectAssets()
    {
        Caching.CleanCache();

        string resPath = Application.dataPath + "/BuildRes/Effect/";
        
        if (System.IO.Directory.Exists(targetPath))
            System.IO.Directory.Delete(targetPath, true);
        System.IO.Directory.CreateDirectory(targetPath);

        List<string> pathList = GetAllEffects(resPath);

        foreach (string path in pathList)
        {
            string pathDir = System.IO.Path.GetDirectoryName(path);
            string fileName = path.Substring(pathDir.Length + 1, path.Length - pathDir.Length - 1 - ".prefab".Length);
            int nPos = path.IndexOf("Assets/BuildRes/Effect");
            string assetPath = path.Substring(nPos);
            Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
            if (null != asset)
            {
                if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle",
                   //BuildAssetBundleOptions.UncompressedAssetBundle |
                   BuildAssetBundleOptions.CollectDependencies |
                   BuildAssetBundleOptions.CompleteAssets,
                   TargetPlatform.buildTarget))
                {
                    Debug.Log("Create effect Success: " + fileName);
                }
                else
                    Debug.LogError("Create effect Asset Error!!! " + fileName);
            }
            else
            {
                Debug.LogError("Create effect Asset Error!!! " + fileName);
            }
        }

        AssetDatabase.Refresh();

        // 往主工程里拷贝文件
        int mPos = targetPath.LastIndexOf("QNYH_Art_Res/Assets");
        mainProjectPath = targetPath.Substring(0, mPos);
        mainProjectPath += "GuJian/Assets/StreamingAssets/Effect/";
        if (Directory.Exists(mainProjectPath))
        {
            Directory.Delete(mainProjectPath, true);
        }
        DirectoryInfo info = Directory.CreateDirectory(mainProjectPath);

        string[] srcDirEntries = System.IO.Directory.GetFileSystemEntries(targetPath);
        for (int i = 0; i < srcDirEntries.Length; ++i)
        {
            string path = srcDirEntries[i];
            if (!path.EndsWith(".assetbundle"))
                continue;

            string pathDir = System.IO.Path.GetDirectoryName(path);
            string fileName = path.Substring(pathDir.Length + 1, path.Length - pathDir.Length - 1);

            File.Copy(targetPath + "/" + fileName, mainProjectPath + "/" + fileName, true);
            Debug.Log(targetPath + "/" + fileName + " ===>>> " + mainProjectPath + "/" + fileName);
        }

    }

    [MenuItem(@"BundleBuilder/Effect/Create Current Effect Asset.")]
        
    public static void CreateCurrentEffectAsset()
    {
        Caching.CleanCache();
        Object[] selectedAssets = Selection.GetFiltered(typeof(Object), SelectionMode.DeepAssets);

        foreach (Object asset in selectedAssets)
        {
            {
                string targetPath = Application.dataPath + "/StreamingAssets/Effect/" + asset.name + ".assetbundle";

                if (BuildPipeline.BuildAssetBundle(asset, null, targetPath,
                    //BuildAssetBundleOptions.UncompressedAssetBundle |
                    BuildAssetBundleOptions.CollectDependencies |
                    BuildAssetBundleOptions.CompleteAssets,
                    TargetPlatform.buildTarget))
                {
                    Debug.Log("Create effect Success: " + asset.name);
                }
                else
                {
                    Debug.LogError("Create effect Asset Error!!! " + asset.name);
                }
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem(@"BundleBuilder/Effect/Create All Effects Assets - PC.")]
    public static void CreateAllEffectAssets_PC()
    {
        TargetPlatform.SwitchWindowsPlatform();
        targetPath = Application.dataPath + "/StreamingAssets/Effect_PC/";
        CreateAllEffectAssets();
    }

    [MenuItem(@"BundleBuilder/Effect/Create All Effects Assets - iOS.")]
    public static void CreateAllEffectAssets_iOS()
    {
        TargetPlatform.SwitchIOSPlatform();
        targetPath = Application.dataPath + "/StreamingAssets/Effect_iOS/";
        CreateAllEffectAssets();
    }

    [MenuItem(@"BundleBuilder/Effect/Create All Effects Assets - Android.")]
    public static void CreateAllEffectAssets_Android()
    {
        TargetPlatform.SwitchAndroidPlatform();
        targetPath = Application.dataPath + "/StreamingAssets/Effect_Android/";
        CreateAllEffectAssets();
    }

    static List<string> GetAllEffects(string path)
    {
        List<string> pathList = new List<string>();
        string[] directoryEntries = System.IO.Directory.GetFileSystemEntries(path);
        for (int i = 0; i < directoryEntries.Length; ++i)
        {
            string p = directoryEntries[i];

            if (p.EndsWith(".meta"))
                continue;

            string[] subDir = System.IO.Directory.GetFileSystemEntries(p);
            if (subDir != null && subDir.Length > 1)
            {
                foreach (string sub in subDir)
                {
                    pathList.AddRange(GetAllEffects(sub));
                }
            }
            else
            {
                pathList.Add(p);
            }
        }
        return pathList;
    }
}
