﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class BuildOpera : MonoBehaviour
{
	static string targetPath = Application.dataPath + "/StreamingAssets/Opera/";
	static string mainProjectPath = targetPath;
	
	[MenuItem(@"BundleBuilder/Opera/Create All Opera Assets.")]
	public static void CreateAllEffectAssets()
	{
		Caching.CleanCache();
		
		string resPath = Application.dataPath + "/BuildRes/Sequence/";
		
		if (System.IO.Directory.Exists(targetPath))
			System.IO.Directory.Delete(targetPath, true);
		System.IO.Directory.CreateDirectory(targetPath);
		
		List<string> pathList = GetAllOperas(resPath);
		
		foreach (string path in pathList)
		{
			Debug.Log(path);
			string pathDir = System.IO.Path.GetDirectoryName(path);
			string fileName = path.Substring(pathDir.Length + 1, path.Length - pathDir.Length - 1 - ".prefab".Length);
			int nPos = path.IndexOf("Assets/BuildRes/Sequence");
			string assetPath = path.Substring(nPos);
			Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
			if (null != asset)
			{
				if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle",
				                                   //BuildAssetBundleOptions.UncompressedAssetBundle |
				                                   BuildAssetBundleOptions.CollectDependencies |
				                                   BuildAssetBundleOptions.CompleteAssets,
				                                   TargetPlatform.buildTarget))
				{
					Debug.Log("Create Opera Success: " + fileName);
				}
				else
					Debug.LogError("Create Opera Asset Error!!! " + fileName);
			}
			else
			{
				Debug.LogError("Create effect Opera Error!!! " + fileName);
			}
		}
		
		AssetDatabase.Refresh();

		return;

		// 往主工程里拷贝文件
		int mPos = targetPath.LastIndexOf("/Assets");
		mainProjectPath = targetPath.Substring(0, mPos);
		mainProjectPath += "GuJian/Assets/StreamingAssets/Opera/";
		if (Directory.Exists(mainProjectPath))
		{
			Directory.Delete(mainProjectPath, true);
		}
		DirectoryInfo info = Directory.CreateDirectory(mainProjectPath);
		
		string[] srcDirEntries = System.IO.Directory.GetFileSystemEntries(targetPath);
		for (int i = 0; i < srcDirEntries.Length; ++i)
		{
			string path = srcDirEntries[i];
			if (!path.EndsWith(".assetbundle"))
				continue;
			
			string pathDir = System.IO.Path.GetDirectoryName(path);
			string fileName = path.Substring(pathDir.Length + 1, path.Length - pathDir.Length - 1);
			
			File.Copy(targetPath + "/" + fileName, mainProjectPath + "/" + fileName, true);
			Debug.Log(targetPath + "/" + fileName + " ===>>> " + mainProjectPath + "/" + fileName);
		}
		
	}

	[MenuItem(@"BundleBuilder/Opera/Create Current Opera Asset.")]
	
	public static void CreateCurrentEffectAsset()
	{
		Caching.CleanCache();
		Object[] selectedAssets = Selection.GetFiltered(typeof(Object), SelectionMode.DeepAssets);
		
		foreach (Object asset in selectedAssets)
		{
			{
				string targetPath = Application.dataPath + "/StreamingAssets/Opera/" + asset.name + ".assetbundle";
				
				if (BuildPipeline.BuildAssetBundle(asset, null, targetPath,
				                                   //BuildAssetBundleOptions.UncompressedAssetBundle |
				                                   BuildAssetBundleOptions.CollectDependencies |
				                                   BuildAssetBundleOptions.CompleteAssets,
				                                   TargetPlatform.buildTarget))
				{
					Debug.Log("Create Opera Success: " + asset.name);
				}
				else
				{
					Debug.LogError("Create Opera Asset Error!!! " + asset.name);
				}
			}
		}
		
		AssetDatabase.Refresh();
	}

	private static List<string> GetAllOperas(string path)
	{
		List<string> pathList = new List<string>();
		string[] directoryEntries = System.IO.Directory.GetFileSystemEntries(path);
		for (int i = 0; i < directoryEntries.Length; ++i)
		{
			string p = directoryEntries[i];
			string[] subDir = System.IO.Directory.GetFileSystemEntries(p);
			if (subDir != null && subDir.Length > 1)
			{
				foreach (string sub in subDir)
				{
					pathList.AddRange(GetAllOperas(sub));
				}
			}
			else
			{
				if (!p.EndsWith(".prefab"))
					continue;

				pathList.Add(p);
			}
		}
		return pathList;
	}


}
