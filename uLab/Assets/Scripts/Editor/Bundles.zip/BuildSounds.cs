﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class BuildSounds : MonoBehaviour
{
	static string targetPath = Application.dataPath + "/StreamingAssets/Sounds/";
	static string mainProjectPath = targetPath;
	
	[MenuItem(@"BundleBuilder/Sounds/Create All Sounds Assets.")]
	public static void CreateAllEffectAssets()
	{
		Caching.CleanCache();
		
		string resPath = Application.dataPath + "/BuildRes/Sounds/";
		
		if (System.IO.Directory.Exists(targetPath))
			System.IO.Directory.Delete(targetPath, true);
		System.IO.Directory.CreateDirectory(targetPath);
		
		List<string> pathList = GetAllSoundsAssets(resPath);
		
		foreach (string path in pathList)
		{
			string pathDir = System.IO.Path.GetDirectoryName(path);
			string fileName = path.Substring(pathDir.Length + 1, path.Length - pathDir.Length - 1 - ".mp3".Length);
			int nPos = path.IndexOf("Assets/BuildRes/Sounds");
			string assetPath = path.Substring(nPos);
			Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
			if (null != asset)
			{
				if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle",
				                                   //BuildAssetBundleOptions.UncompressedAssetBundle |
				                                   BuildAssetBundleOptions.CollectDependencies |
				                                   BuildAssetBundleOptions.CompleteAssets,
				                                   TargetPlatform.buildTarget))
				{
					Debug.Log("Create Sound Success: " + fileName);
				}
				else
					Debug.LogError("Create Sound Asset Error!!! " + fileName);
			}
			else
			{
				Debug.LogError("Create Sound Asset Error!!! " + fileName);
			}
		}
		
		AssetDatabase.Refresh();
		
		// 往主工程里拷贝文件
		int mPos = targetPath.LastIndexOf("QNYH_Art_Res/Assets");
		mainProjectPath = targetPath.Substring(0, mPos);
		mainProjectPath += "GuJian/Assets/StreamingAssets/Sounds/";
		if (Directory.Exists(mainProjectPath))
		{
			Directory.Delete(mainProjectPath, true);
		}
		DirectoryInfo info = Directory.CreateDirectory(mainProjectPath);
		
		string[] srcDirEntries = System.IO.Directory.GetFileSystemEntries(targetPath);
		for (int i = 0; i < srcDirEntries.Length; ++i)
		{
			string path = srcDirEntries[i];
			if (!path.EndsWith(".assetbundle"))
				continue;
			
			string pathDir = System.IO.Path.GetDirectoryName(path);
			string fileName = path.Substring(pathDir.Length + 1, path.Length - pathDir.Length - 1);
			
			File.Copy(targetPath + "/" + fileName, mainProjectPath + "/" + fileName, true);
			Debug.Log(targetPath + "/" + fileName + " ===>>> " + mainProjectPath + "/" + fileName);
		}
		
	}

    [MenuItem(@"BundleBuilder/Sounds/Create Current Sound Asset.")]
	
	public static void CreateCurrentEffectAsset()
	{
		Caching.CleanCache();
		Object[] selectedAssets = Selection.GetFiltered(typeof(Object), SelectionMode.DeepAssets);
		
		foreach (Object asset in selectedAssets)
		{
			{
				string targetPath = Application.dataPath + "/StreamingAssets/Sounds/" + asset.name + ".assetbundle";
				
				if (BuildPipeline.BuildAssetBundle(asset, null, targetPath,
				                                   //BuildAssetBundleOptions.UncompressedAssetBundle |
				                                   BuildAssetBundleOptions.CollectDependencies |
				                                   BuildAssetBundleOptions.CompleteAssets,
				                                   TargetPlatform.buildTarget))
				{
					Debug.Log("Create Sound Success: " + asset.name);
				}
				else
				{
					Debug.LogError("Create Sound Asset Error!!! " + asset.name);
				}
			}
		}
		
		AssetDatabase.Refresh();
	}
	
	static List<string> GetAllSoundsAssets(string path)
	{
		List<string> pathList = new List<string>();
		string[] directoryEntries = System.IO.Directory.GetFileSystemEntries(path);
		for (int i = 0; i < directoryEntries.Length; ++i)
		{
			string p = directoryEntries[i];
			
			if (p.EndsWith(".meta"))
				continue;
			
			string[] subDir = System.IO.Directory.GetFileSystemEntries(p);
			if (subDir != null && subDir.Length > 1)
			{
				foreach (string sub in subDir)
				{
					pathList.AddRange(GetAllSoundsAssets(sub));
				}
			}
			else
			{
				pathList.Add(p);
			}
		}
		return pathList;
	}
}
