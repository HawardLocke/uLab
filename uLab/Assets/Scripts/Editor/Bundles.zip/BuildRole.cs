﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class BuildRole : MonoBehaviour
{
    [MenuItem("BundleBuilder/Role/Create Selected Role Asset")]
    public static void CreateSelectedAsset()
    {
        Caching.CleanCache();
        Object[] selectedAssets = Selection.GetFiltered(typeof(Object), SelectionMode.DeepAssets);

        foreach (Object asset in selectedAssets)
        {
            string path = AssetDatabase.GetAssetPath(asset.GetInstanceID());
            string targetPath  = path.Replace(".prefab", ".assetbundle");

            Debug.Log(path + " ===>>> " + targetPath);

            if (BuildPipeline.BuildAssetBundle(asset, null, targetPath,
                BuildAssetBundleOptions.CollectDependencies |
                BuildAssetBundleOptions.CompleteAssets,
                //BuildAssetBundleOptions.UncompressedAssetBundle,
                TargetPlatform.buildTarget))
            {
                Debug.Log(asset.name + ": create assetbundle success!!!");
            }
            else
            {
                Debug.Log(asset.name + ": create assetbundle failed!!!");
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create Player Assets")]
    public static void CreatePlayerAssets()
    {
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
        string targetPath = Application.dataPath + "/StreamingAssets/Role/Player/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        // 打包登录场景角色
        string loginPath = Application.dataPath + "/BuildRes/Roles/Player/Login/";
        string[] loginDir = System.IO.Directory.GetFileSystemEntries(loginPath);
        foreach (string p in loginDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Player/Login");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc = 0;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc, 
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {

                        Debug.Log("Create LoginRoleRes Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create LoginRoleRes Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create LoginRoleRes Asset Error!!! " + fileName);
                }
            }
        }

        // 打包主角
        string playerPath = Application.dataPath + "/BuildRes/Roles/Player/Player/";
        string[] playerDir = System.IO.Directory.GetFileSystemEntries(playerPath);
        foreach (string p in playerDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Player/Player");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc = 0;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create RoleRes Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create RoleRes Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create RoleRes Asset Error!!! " + fileName);
                }
            }
        }

        // 打包雕像
        string diaoxiangPath = Application.dataPath + "/BuildRes/Roles/Player/Diaoxiang/";
        string[] diaoxiangDir = System.IO.Directory.GetFileSystemEntries(diaoxiangPath);
        foreach (string p in diaoxiangDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Player/Diaoxiang");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc = 0;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                        //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create RoleRes Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create RoleRes Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create RoleRes Asset Error!!! " + fileName);
                }
            }
        }

        // 打包时装
        string shizhuangPath = Application.dataPath + "/BuildRes/Roles/Player/Shizhuang/";
        string[] shizhuangDir = System.IO.Directory.GetFileSystemEntries(shizhuangPath);
        foreach (string p in shizhuangDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Player/Shizhuang");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc = 0;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                        //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create RoleRes Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create RoleRes Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create RoleRes Asset Error!!! " + fileName);
                }
            }
        }


        // 打包武器
        string weaponPath = Application.dataPath + "/BuildRes/Roles/Player/Weapon/";
        string[] weaponDir = System.IO.Directory.GetFileSystemEntries(weaponPath);
        foreach (string p in weaponDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Player/Weapon");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc = 0;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create WeaponRes Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create WeaponRes Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create WeaponRes Asset Error!!! " + fileName);
                }
            }
        }
        
        // 打包贴图
        targetPath = Application.dataPath + "/StreamingAssets/Texture/Player/";
		if (System.IO.Directory.Exists(targetPath))
		{
			System.IO.Directory.Delete(targetPath, true);
		}
		System.IO.Directory.CreateDirectory(targetPath);

        string texPath = Application.dataPath + "/BuildRes/Roles/Player/Texture/";
        string[] texDir = System.IO.Directory.GetFileSystemEntries(texPath);
        foreach (string p in texDir)
        {
            if (p.EndsWith(".jpg") || p.EndsWith(".tga"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Player/Texture");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".jpg".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create PlayerTex Success: " + targetPath + "/" + fileName);
                    }
                    else
                        Debug.LogError("Create PlayerTex Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create PlayerTex Asset Error!!! " + fileName);
                }
            }
        }
        
        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create NPC Assets")]
    public static void CreateNPCAssets()
    {
        // 打包NPC
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
        string targetPath = Application.dataPath + "/StreamingAssets/Role/NPC/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        string npcPath = Application.dataPath + "/BuildRes/Roles/NPC/";
        string[] npcDir = System.IO.Directory.GetFileSystemEntries(npcPath);
        foreach (string p in npcDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/NPC");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create NPC Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create NPC Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create NPC Asset Error!!! " + fileName);
                }
            }
        }

        AssetDatabase.Refresh();
    }


    [MenuItem("BundleBuilder/Role/Create Monster Assets")]
    public static void CreateMonsterAssets()
    {
        // 打包MonsterPrefab
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
        string targetPath = Application.dataPath + "/StreamingAssets/Role/Monster/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        string npcPath = Application.dataPath + "/BuildRes/Roles/Monster/";
        string[] npcDir = System.IO.Directory.GetFileSystemEntries(npcPath);
        foreach (string p in npcDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Monster");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                        //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create MonsterPrefab Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create MonsterPrefab Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create MonsterPrefab Asset Error!!! " + fileName);
                }
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create Juqing Role Assets")]
    public static void CreateJuqingRoleAssets()
    {
        // 打包JuqingPrefab
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
        string targetPath = Application.dataPath + "/StreamingAssets/Role/Juqing/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        string npcPath = Application.dataPath + "/BuildRes/Roles/Juqing/";
        string[] npcDir = System.IO.Directory.GetFileSystemEntries(npcPath);
        foreach (string p in npcDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Juqing");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                        //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create JuqingPrefab Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create JuqingPrefab Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create JuqingPrefab Asset Error!!! " + fileName);
                }
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create Wing Assets")]
    public static void CreateWingAssets()
    {
        // 打包Wing
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
        string targetPath = Application.dataPath + "/StreamingAssets/Role/Wing/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        string wingPath = Application.dataPath + "/BuildRes/Roles/Wing/";
        string[] wingDir = System.IO.Directory.GetFileSystemEntries(wingPath);
        foreach (string p in wingDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Wing");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create Wing Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create Wing Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create Wing Asset Error!!! " + fileName);
                }
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create Soul Assets")]
    public static void CreateSoulAssets()
    {
        // 打包Soul
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
		string targetPath = Application.dataPath + "/StreamingAssets/Role/Soul/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        string wingPath = Application.dataPath + "/BuildRes/Roles/Soul/";
        string[] wingDir = System.IO.Directory.GetFileSystemEntries(wingPath);
        foreach (string p in wingDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Soul");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create Soul Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create Soul Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create Wing Soul Error!!! " + fileName);
                }
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create Ride Assets")]
    public static void CreateRideAssets()
    {
        // 打包Ride
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
		string targetPath = Application.dataPath + "/StreamingAssets/Role/Ride/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        string wingPath = Application.dataPath + "/BuildRes/Roles/Ride/";
        string[] wingDir = System.IO.Directory.GetFileSystemEntries(wingPath);
        foreach (string p in wingDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Ride");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create Ride Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create Ride Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create Ride Asset Error!!! " + fileName);
                }
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create Fabao Assets")]
    public static void CreateFabaoAssets()
    {
        // 打包Ride
        Caching.CleanCache();

        // 保证目标文件夹存在且为空
		string targetPath = Application.dataPath + "/StreamingAssets/Role/Fabao/";
        if (System.IO.Directory.Exists(targetPath))
        {
            System.IO.Directory.Delete(targetPath, true);
        }
        System.IO.Directory.CreateDirectory(targetPath);

        string wingPath = Application.dataPath + "/BuildRes/Roles/Fabao/";
        string[] wingDir = System.IO.Directory.GetFileSystemEntries(wingPath);
        foreach (string p in wingDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Fabao");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                uint crc;
                if (null != asset)
                {
                    if (BuildPipeline.BuildAssetBundle(asset, null, targetPath + fileName + ".assetbundle", out crc,
                       //BuildAssetBundleOptions.UncompressedAssetBundle |
                       BuildAssetBundleOptions.CollectDependencies |
                       BuildAssetBundleOptions.CompleteAssets,
                       TargetPlatform.buildTarget))
                    {
                        Debug.Log("Create Fabao Success: " + fileName);
                    }
                    else
                        Debug.LogError("Create Fabao Asset Error!!! " + fileName);
                }
                else
                {
                    Debug.LogError("Create Fabao Asset Error!!! " + fileName);
                }
            }
        }

        AssetDatabase.Refresh();
    }

    [MenuItem("BundleBuilder/Role/Create All Roles Assets")]
    public static void CreateAllArtRes()
    {
        CreatePlayerAssets();
        CreateNPCAssets();
        CreateMonsterAssets();
        CreateFabaoAssets();
        CreateSoulAssets();
        CreateWingAssets();
        CreateRideAssets();
    }

    [MenuItem("BundleBuilder/Role/Rename All Meshrenderer of Assets")]
    public static void RenameAllMeshrendererOfAssets()
    {
        // 主角
        string playerPath = Application.dataPath + "/BuildRes/Roles/Player/Player/";
        string[] playerDir = System.IO.Directory.GetFileSystemEntries(playerPath);
        foreach (string p in playerDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Player/Player");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                if (null != asset)
                {
                    GameObject obj = asset as GameObject;
                    foreach (Transform child in obj.transform)
                    {
                        SkinnedMeshRenderer meshRenderer = child.GetComponent<SkinnedMeshRenderer>();
                        if (null != meshRenderer)
                        {
                            meshRenderer.name = "Role_Mesh";
                        }
                    }
                    Debug.Log("Rename RoleMesh Success: " + fileName);
                }
            }
        }
        // 翅膀
        string wingPath = Application.dataPath + "/BuildRes/Roles/Wing/";
        string[] wingDir = System.IO.Directory.GetFileSystemEntries(wingPath);
        foreach (string p in wingDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Wing");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                if (null != asset)
                {
                    GameObject obj = asset as GameObject;
                    foreach (Transform child in obj.transform)
                    {
                        SkinnedMeshRenderer meshRenderer = child.GetComponent<SkinnedMeshRenderer>();
                        if (null != meshRenderer)
                        {
                            meshRenderer.name = "Wing_Mesh";
                        }
                    }
                    Debug.Log("Rename WingMesh Success: " + fileName);
                }
            }
        }
        // 法宝
        string fabaoPath = Application.dataPath + "/BuildRes/Roles/Fabao/";
        string[] fabaoDir = System.IO.Directory.GetFileSystemEntries(fabaoPath);
        foreach (string p in fabaoDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Fabao");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);

                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                if (null != asset)
                {
                    GameObject obj = asset as GameObject;
                    foreach (Transform child in obj.transform.GetChild(0))
                    {
                        SkinnedMeshRenderer meshRenderer = child.GetComponent<SkinnedMeshRenderer>();
                        if (null != meshRenderer)
                        {
                            meshRenderer.name = "Fabao_Mesh";
                        }
                    }
                    Debug.Log("Rename FabaoMesh Success: " + fileName);
                }
            }
        }

        // 骑乘
        string ridePath = Application.dataPath + "/BuildRes/Roles/Ride/";
        string[] rideDir = System.IO.Directory.GetFileSystemEntries(ridePath);
        foreach (string p in rideDir)
        {
            if (p.EndsWith(".prefab"))
            {
                int nPos = p.IndexOf("Assets/BuildRes/Roles/Ride");
                string assetPath = p.Substring(nPos);
                nPos = assetPath.LastIndexOf("/");
                string fileName = assetPath.Substring(nPos + 1, assetPath.Length - nPos - 1 - ".prefab".Length);
                
                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                if (null != asset)
                {
                    GameObject obj = asset as GameObject;
                    foreach (Transform child in obj.transform)
                    {
                        if (child.name.StartsWith("Qc_"))
                        {
                            SkinnedMeshRenderer meshRenderer = child.GetComponent<SkinnedMeshRenderer>();
                            if (null != meshRenderer)
                            {
                                meshRenderer.name = "Ride_Mesh";
                            }
                        }
                    }
                    Debug.Log("Rename RideMesh Success: " + fileName);
                }
            }
        }
    }

    static List<string> GetAllAssetbundle(string path)
    {
        List<string> pathList = new List<string>();
        string[] directoryEntries = System.IO.Directory.GetFileSystemEntries(path);
        for (int i = 0; i < directoryEntries.Length; ++i)
        {
            string p = directoryEntries[i];

            if (p.EndsWith(".meta"))
                continue;

            string[] subDir = System.IO.Directory.GetFileSystemEntries(p);
            if (subDir != null && subDir.Length > 1)
            {
                foreach (string sub in subDir)
                {
                    pathList.AddRange(GetAllAssetbundle(sub));
                }
            }
            else
            {
                p = p.Replace("\\", "/");
                int npos = p.IndexOf("AssetBundle/Res");
                int length = "AssetBundle/Res".Length;
                p = p.Substring(npos + length, p.Length - npos - length);
                pathList.Add(p);
            }
        }
        return pathList;
    }
}
