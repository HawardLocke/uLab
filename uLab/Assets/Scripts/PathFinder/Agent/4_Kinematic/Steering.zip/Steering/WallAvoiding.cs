﻿
using UnityEngine;


namespace Lite
{
	public class WallAvoiding : Steering
	{

		public override Vector3 Calculate(LocomotionComponent loco)
		{
			return Vector3.zero;
		}

	}
}
