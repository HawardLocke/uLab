namespace Lite
{
	public enum SteeringType
	{
		None = 0,
		Seek = 1,
		Arrive = 2,
		Wander = 4,
		Separation = 8,
		WallAvoidance = 16,
	}
	
}
