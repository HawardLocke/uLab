﻿using UnityEngine;
using System.Collections;

// Base window data context for Refresh window or show window
public class BaseWindowContextData
{

}

// Example
// Rank window context data pass to UIRankWindow
//public class WindowContextData_Rank : BaseWindowContextData
//{
//}

// Skill window context data pass to UISkillWindow
//public class WindowContextData_Skill : BaseWindowContextData
//{
//}